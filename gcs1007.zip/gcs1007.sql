-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th8 24, 2023 lúc 10:27 AM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `gcs1007`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admins`
--
use gcs1007;
CREATE TABLE `admins` (
  `adminID` varchar(50) NOT NULL,
  `adminPass` int(11) NOT NULL,
  `adminPhoto` varchar(100) NOT NULL,
  `adminFullname` varchar(50) NOT NULL,
  `adminAddress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `admins`
--

INSERT INTO `admins` (`adminID`, `adminPass`, `adminPhoto`, `adminFullname`, `adminAddress`) VALUES
('admin01', 123456, 'admin1.jpg', 'Nguyen Thanh Hieu Le', 'No address'),
('admin02', 123456, 'admin2.jpg', 'Cao Dang Vinh Khoa', 'No address'),
('admin03', 123456, 'admin3.jpg', 'Pham Quoc Nhut', 'No address'),
('admin04', 123456, 'admin4.jpg', 'Tran Tien Dat', 'No address');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `catID` int(11) NOT NULL,
  `catName` varchar(100) NOT NULL,
  `catDescriptions` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`catID`, `catName`, `catDescriptions`) VALUES
(1, 'Laptop', NULL),
(2, 'Tablet', NULL),
(3, 'Computer', NULL),
(4, 'Mobile Phone', NULL),
(5, 'Accessories', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comments`
--

CREATE TABLE `comments` (
  `commentID` varchar(50) NOT NULL,
  `commentContents` int(11) NOT NULL,
  `commentStar` tinyint(4) NOT NULL,
  `productID` varchar(50) NOT NULL,
  `CustommerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customers`
--

CREATE TABLE `customers` (
  `customerID` int(11) NOT NULL,
  `customerPassword` varchar(500) NOT NULL,
  `customerEmail` varchar(50) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerAddress` varchar(100) NOT NULL,
  `customerPhone` varchar(50) NOT NULL,
  `customerPhoto` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `invoices`
--

CREATE TABLE `invoices` (
  `invoiceNumber` bigint(50) NOT NULL,
  `invoiceDate` date NOT NULL,
  `invoiceContents` int(11) DEFAULT NULL,
  `adminID` varchar(50) NOT NULL,
  `CustommerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `manufacturers`
--

CREATE TABLE `manufacturers` (
  `manufacturerID` varchar(50) NOT NULL,
  `manufacturerName` varchar(50) NOT NULL,
  `manufacturerLogo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `manufacturers`
--

INSERT INTO `manufacturers` (`manufacturerID`, `manufacturerName`, `manufacturerLogo`) VALUES
('1', 'Acer', 'logo-acer.jpg'),
('2', 'Apple', 'LogoIP.jpg'),
('3', 'ASUS', 'logo-asus.jpg'),
('4', 'Dell', 'logo-dell.png'),
('5', 'Lenove', 'Lenovo-Logo.jpg'),
('6', 'SamSung', 'LogoSS.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `productID` varchar(50) NOT NULL,
  `productName` varchar(50) NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productDate` date DEFAULT NULL,
  `productDetails` varchar(500) NOT NULL,
  `productImage1` varchar(100) NOT NULL,
  `productImage2` varchar(100) DEFAULT NULL,
  `productImage3` varchar(100) DEFAULT NULL,
  `manufacturerID` varchar(50) NOT NULL,
  `catID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`productID`, `productName`, `productPrice`, `productDate`, `productDetails`, `productImage1`, `productImage2`, `productImage3`, `manufacturerID`, `catID`) VALUES
('LA001', 'Laptop Dell XPS 15 9520 i9', 2300, '2023-08-11', '', 'la01.jpg', NULL, NULL, '4', 1),
('LA002', 'Laptop Dell Inspiron 16 N5620 i5', 1050, '2023-08-11', '', 'la02.jpg', NULL, NULL, '4', 1),
('LA003', 'Laptop Lenovo Yoga Slim 7 Pro', 900, '2023-08-11', '', 'la03.jpg', NULL, NULL, '5', 1),
('LA004', 'Laptop Lenovo ThinkPad X1 Carbon Gen 9', 1850, 2023-08-11, '', 'la04.jpg', NULL, NULL, '5', 1),
('MB001', 'iPhone 14 Pro Max 128GB', 1300, '2023-08-11', '', 'mb01.jpg', NULL, NULL, '2', 4),
('MB002', 'iPhone 14 Pro 128GB', 990, '2023-08-11', '', 'mb02.jpg', NULL, NULL, '2', 4),
('MB003', 'iPhone 14 Plus 128GB', 1100, '2023-08-11', '', 'mb03.jpg', NULL, NULL, '2', 4),
('MB004', 'iPhone 14 128GB', 950, '2023-08-11', '', 'mb04.jpg', NULL, NULL, '2', 4),
('MB005', 'iPhone 14 Pro Max 512GB', 1500, '2023-08-11', '', 'mb05.jpg', NULL, NULL, '2', 3),
('PC001', 'PC E-Power Office 04', 300, '2023-08-11', '', 'pc01.jpg', NULL, NULL, '3', 3),
('PC002', 'PC E-Power Office 07 Core i5', 350, '2023-08-11', '', 'pc02.jpg', NULL, NULL, '1', 3),
('PC003', 'PC Gaming E-Power F1650 i5', 400, '2023-08-11', '', 'pc03.jpg', NULL, NULL, '3', 3),
('PC004', 'PC Gaming E-Power G1650 i3', 450, '2023-08-11', '', 'pc04.jpg', NULL, NULL, '5', 3),
('PC005', 'PC Gaming E-Power 030 i5', 500, 2023-08-11, '', 'pc05.jpg', NULL, NULL, '1', 3),
('SS01', 'Samsung Galaxy Fold5 12GB 1TB', 990, '2023-08-11', '', 'SS01.jpg', NULL, NULL, '6', 4),
('SS02', 'Samsung Galaxy Z Flip4 128GB', 880, '2023-08-11', '', 'ss02.jpg', NULL, NULL, '6', 4),
('TL001', 'iPad Pro 11 2022 M2 WiFi 128GB', 1200, '2023-08-11', '', 'tl01.jpg', NULL, NULL, '2', 2),
('TL002', 'iPad Pro 11 2022 M2 WiFi 1TB', 1600, '2023-08-11', '', 'tl02.jpg', NULL, NULL, '2', 2),
('TL003', 'iPad Pro 12.9 2022 M2 WiFi 1TB', 1900, '2023-08-11', '', 'tl03.jpg', NULL, NULL, '2', 2),
('TL004', 'iPad Pro 11 2021 M1 Wi-Fi 1TB', 1500, '2023-08-11', '', 'tl04.jpg', NULL, NULL, '2', 2);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`adminID`);

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catID`),
  ADD UNIQUE KEY `catName` (`catName`);

--
-- Chỉ mục cho bảng `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`),
  ADD KEY `productID` (`productID`),
  ADD KEY `CustommerID` (`CustommerID`);

--
-- Chỉ mục cho bảng `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerID`);

--
-- Chỉ mục cho bảng `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`invoiceNumber`),
  ADD KEY `saffEmail` (`adminID`),
  ADD KEY `CustommerID` (`CustommerID`);

--
-- Chỉ mục cho bảng `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`manufacturerID`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `manufacturerID` (`manufacturerID`,`catID`),
  ADD KEY `catID` (`catID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `catID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `customers`
--
ALTER TABLE `customers`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`CustommerID`) REFERENCES `customers` (`customerID`);

--
-- Các ràng buộc cho bảng `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`CustommerID`) REFERENCES `customers` (`customerID`);

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`catID`) REFERENCES `categories` (`catID`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`manufacturerID`) REFERENCES `manufacturers` (`manufacturerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
